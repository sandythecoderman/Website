const { chromium } = require('playwright');

async function test24_7Position() {
    console.log('🔍 Testing 24/7 positioning and breathing effect...');
    
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    
    try {
        // Navigate to the home page
        await page.goto('http://localhost:8080/');
        console.log('✅ Loaded home page');
        
        // Wait for the page to load completely
        await page.waitForLoadState('networkidle');
        
        // Find the ROI section
        const roiSection = await page.locator('.roi-section');
        if (await roiSection.count() > 0) {
            console.log('✅ Found ROI section');
            
            // Find the 24/7 card specifically
            const card24_7 = await page.locator('.roi-card').filter({ hasText: '24/7' });
            if (await card24_7.count() > 0) {
                console.log('✅ Found 24/7 card');
                
                // Get the position and dimensions
                const box = await card24_7.boundingBox();
                console.log('📊 24/7 Card Position:', {
                    x: box.x,
                    y: box.y,
                    width: box.width,
                    height: box.height
                });
                
                // Check if the 24/7 text has breathing animation
                const text24_7 = await page.locator('.roi-card').filter({ hasText: '24/7' }).locator('.roi-number');
                if (await text24_7.count() > 0) {
                    const computedStyle = await text24_7.evaluate(el => {
                        return {
                            animation: window.getComputedStyle(el).animation,
                            transform: window.getComputedStyle(el).transform,
                            position: window.getComputedStyle(el).position
                        };
                    });
                    
                    console.log('🎭 24/7 Text Animation:', computedStyle);
                    
                    if (computedStyle.animation.includes('breathing')) {
                        console.log('❌ 24/7 text has breathing animation - needs to be removed');
                    } else {
                        console.log('✅ 24/7 text has no breathing animation');
                    }
                }
                
                // Check alignment with other cards
                const allCards = await page.locator('.roi-card').all();
                console.log(`📋 Found ${allCards.length} ROI cards total`);
                
                for (let i = 0; i < allCards.length; i++) {
                    const card = allCards[i];
                    const cardText = await card.textContent();
                    const cardBox = await card.boundingBox();
                    console.log(`Card ${i + 1} (${cardText.trim().split('\n')[0]}):`, {
                        y: cardBox.y,
                        height: cardBox.height
                    });
                }
                
            } else {
                console.log('❌ Could not find 24/7 card');
            }
        } else {
            console.log('❌ Could not find ROI section');
        }
        
        // Take a screenshot for visual inspection
        await page.screenshot({ path: 'roi_section_debug.png', fullPage: true });
        console.log('📸 Screenshot saved as roi_section_debug.png');
        
    } catch (error) {
        console.error('❌ Error during test:', error);
    } finally {
        await browser.close();
    }
}

test24_7Position(); 