const { chromium } = require('playwright');

async function testLogoFont() {
    console.log('🎨 Testing Skenzer Logo Font and Theme...');
    
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    
    try {
        // Navigate to the website
        await page.goto('http://localhost:8080');
        console.log('✅ Page loaded successfully');
        
        // Wait for fonts to load
        await page.waitForTimeout(3000);
        
        // Check if Nyxerin font is loaded
        const fonts = await page.evaluate(() => {
            return document.fonts.ready.then(() => {
                return Array.from(document.fonts).map(font => font.family);
            });
        });
        
        console.log('📝 Available fonts:', fonts);
        const nyxerinLoaded = fonts.some(font => font.toLowerCase().includes('nyxerin'));
        console.log('🎯 Nyxerin font loaded:', nyxerinLoaded);
        
        // Check navigation logo
        const navLogo = await page.$('.nav-logo h2');
        if (navLogo) {
            const navLogoText = await navLogo.textContent();
            const navLogoColor = await navLogo.evaluate(el => {
                const style = window.getComputedStyle(el);
                return {
                    color: style.color,
                    fontFamily: style.fontFamily,
                    fontSize: style.fontSize,
                    fontWeight: style.fontWeight
                };
            });
            
            console.log('🔍 Navigation Logo:');
            console.log('  Text:', navLogoText);
            console.log('  Color:', navLogoColor.color);
            console.log('  Font Family:', navLogoColor.fontFamily);
            console.log('  Font Size:', navLogoColor.fontSize);
            console.log('  Font Weight:', navLogoColor.fontWeight);
            
            // Check if Nyxerin is applied
            const nyxerinApplied = navLogoColor.fontFamily.toLowerCase().includes('nyxerin');
            console.log('  ✅ Nyxerin applied:', nyxerinApplied);
        } else {
            console.log('❌ Navigation logo not found');
        }
        
        // Check footer logo
        const footerLogo = await page.$('.footer-logo h3');
        if (footerLogo) {
            const footerLogoText = await footerLogo.textContent();
            const footerLogoColor = await footerLogo.evaluate(el => {
                const style = window.getComputedStyle(el);
                return {
                    color: style.color,
                    fontFamily: style.fontFamily,
                    fontSize: style.fontSize,
                    fontWeight: style.fontWeight
                };
            });
            
            console.log('🔍 Footer Logo:');
            console.log('  Text:', footerLogoText);
            console.log('  Color:', footerLogoColor.color);
            console.log('  Font Family:', footerLogoColor.fontFamily);
            console.log('  Font Size:', footerLogoColor.fontSize);
            console.log('  Font Weight:', footerLogoColor.fontWeight);
            
            // Check if Nyxerin is applied
            const nyxerinApplied = footerLogoColor.fontFamily.toLowerCase().includes('nyxerin');
            console.log('  ✅ Nyxerin applied:', nyxerinApplied);
        } else {
            console.log('❌ Footer logo not found');
        }
        
        // Test theme switching
        console.log('\n🌙 Testing theme switching...');
        
        // Get current theme
        const currentTheme = await page.evaluate(() => {
            return document.documentElement.getAttribute('data-theme') || 'dark';
        });
        console.log('  Current theme:', currentTheme);
        
        // Click theme toggle
        const themeToggle = await page.$('.theme-toggle');
        if (themeToggle) {
            await themeToggle.click();
            await page.waitForTimeout(1000);
            
            // Check new theme
            const newTheme = await page.evaluate(() => {
                return document.documentElement.getAttribute('data-theme') || 'dark';
            });
            console.log('  New theme:', newTheme);
            
            // Check logo color after theme change
            const navLogoColorAfter = await navLogo.evaluate(el => {
                const style = window.getComputedStyle(el);
                return style.color;
            });
            console.log('  Logo color after theme change:', navLogoColorAfter);
            
            // Switch back
            await themeToggle.click();
            await page.waitForTimeout(1000);
        }
        
        // Take a screenshot
        await page.screenshot({ path: 'logo-test.png', fullPage: true });
        console.log('📸 Screenshot saved as logo-test.png');
        
    } catch (error) {
        console.error('❌ Error during testing:', error);
    } finally {
        await browser.close();
    }
}

// Check if Node.js is available
if (typeof require !== 'undefined') {
    testLogoFont().catch(console.error);
} else {
    console.log('Node.js not available, trying alternative approach...');
} 