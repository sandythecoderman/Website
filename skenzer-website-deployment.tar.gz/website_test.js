const { chromium } = require('playwright');

async function testWebsite() {
    console.log('🌐 Starting comprehensive website test...');
    
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    
    const pages = [
        { name: 'Home', url: 'http://localhost:8080/' },
        { name: 'About', url: 'http://localhost:8080/about.html' },
        { name: 'Product', url: 'http://localhost:8080/product.html' },
        { name: 'Contact', url: 'http://localhost:8080/contact.html' }
    ];
    
    try {
        for (const pageInfo of pages) {
            console.log(`\n📄 Testing ${pageInfo.name} page...`);
            
            // Navigate to page
            await page.goto(pageInfo.url);
            await page.waitForTimeout(2000);
            
            // Test both themes
            await testPageInTheme(page, pageInfo.name, 'dark');
            await testPageInTheme(page, pageInfo.name, 'light');
        }
        
        // Take screenshots of all pages in both themes
        await takeScreenshots(browser);
        
    } catch (error) {
        console.error('❌ Error during testing:', error);
    } finally {
        await browser.close();
    }
}

async function testPageInTheme(page, pageName, theme) {
    console.log(`  🎨 Testing ${pageName} in ${theme} mode...`);
    
    // Set theme
    if (theme === 'light') {
        await page.evaluate(() => {
            document.documentElement.setAttribute('data-theme', 'light');
        });
        await page.waitForTimeout(1000);
    } else {
        await page.evaluate(() => {
            document.documentElement.setAttribute('data-theme', 'dark');
        });
        await page.waitForTimeout(1000);
    }
    
    // Test text visibility
    await testTextVisibility(page, pageName, theme);
    
    // Test component visibility
    await testComponentVisibility(page, pageName, theme);
    
    // Test interactive elements
    await testInteractiveElements(page, pageName, theme);
}

async function testTextVisibility(page, pageName, theme) {
    console.log(`    📝 Testing text visibility...`);
    
    // Get all text elements
    const textElements = await page.$$eval('h1, h2, h3, h4, h5, h6, p, span, a, li, div', elements => {
        return elements.map(el => {
            const style = window.getComputedStyle(el);
            const rect = el.getBoundingClientRect();
            return {
                tag: el.tagName.toLowerCase(),
                text: el.textContent.trim().substring(0, 50),
                color: style.color,
                backgroundColor: style.backgroundColor,
                fontSize: style.fontSize,
                fontWeight: style.fontWeight,
                visible: rect.width > 0 && rect.height > 0,
                position: { x: rect.x, y: rect.y, width: rect.width, height: rect.height }
            };
        }).filter(item => item.text.length > 0 && item.visible);
    });
    
    // Check for visibility issues
    const visibilityIssues = [];
    
    for (const element of textElements) {
        // Check if text color is too similar to background
        const color = element.color;
        const bgColor = element.backgroundColor;
        
        if (theme === 'light') {
            // In light mode, text should be dark
            if (color.includes('rgb(255, 255, 255)') || color.includes('rgba(255, 255, 255')) {
                visibilityIssues.push({
                    element: `${element.tag}: "${element.text}"`,
                    issue: 'White text in light mode',
                    color: color,
                    backgroundColor: bgColor
                });
            }
        } else {
            // In dark mode, text should be light
            if (color.includes('rgb(0, 0, 0)') || color.includes('rgba(0, 0, 0')) {
                visibilityIssues.push({
                    element: `${element.tag}: "${element.text}"`,
                    issue: 'Black text in dark mode',
                    color: color,
                    backgroundColor: bgColor
                });
            }
        }
    }
    
    if (visibilityIssues.length > 0) {
        console.log(`    ⚠️  Found ${visibilityIssues.length} text visibility issues in ${theme} mode:`);
        visibilityIssues.forEach(issue => {
            console.log(`      - ${issue.element}: ${issue.issue}`);
        });
    } else {
        console.log(`    ✅ Text visibility looks good in ${theme} mode`);
    }
}

async function testComponentVisibility(page, pageName, theme) {
    console.log(`    🧩 Testing component visibility...`);
    
    const components = [
        '.navbar', '.nav-logo', '.nav-menu', '.nav-link',
        '.hero', '.hero-title', '.hero-subtitle', '.cta-button',
        '.section-title', '.subsection-title',
        '.problem-card', '.solution-diagram', '.impact-card',
        '.footer', '.footer-logo', '.footer-links',
        '.theme-toggle', '.hamburger',
        '.pc-eyes-animation', '.floating-icons', '.typing-animation',
        '.geometric-container', '.wave-container', '.pulse-container',
        '.technology-section', '.tech-card', '.tech-detail-card',
        '.contact-form', '.contact-info'
    ];
    
    const visibilityIssues = [];
    
    for (const selector of components) {
        try {
            const element = await page.$(selector);
            if (element) {
                const isVisible = await element.isVisible();
                const rect = await element.boundingBox();
                
                if (!isVisible || !rect || rect.width === 0 || rect.height === 0) {
                    visibilityIssues.push({
                        component: selector,
                        issue: 'Component not visible or has zero dimensions'
                    });
                }
            }
        } catch (error) {
            // Component might not exist on this page, which is fine
        }
    }
    
    if (visibilityIssues.length > 0) {
        console.log(`    ⚠️  Found ${visibilityIssues.length} component visibility issues:`);
        visibilityIssues.forEach(issue => {
            console.log(`      - ${issue.component}: ${issue.issue}`);
        });
    } else {
        console.log(`    ✅ Component visibility looks good`);
    }
}

async function testInteractiveElements(page, pageName, theme) {
    console.log(`    🖱️  Testing interactive elements...`);
    
    const interactiveElements = [
        '.nav-link', '.cta-button', '.theme-toggle', '.style-btn',
        '.hamburger', '.footer-links a', '.footer-social a'
    ];
    
    const interactionIssues = [];
    
    for (const selector of interactiveElements) {
        try {
            const elements = await page.$$(selector);
            for (const element of elements) {
                const isVisible = await element.isVisible();
                const isEnabled = await element.isEnabled();
                
                if (!isVisible || !isEnabled) {
                    interactionIssues.push({
                        element: selector,
                        issue: `Not visible (${isVisible}) or not enabled (${isEnabled})`
                    });
                }
            }
        } catch (error) {
            // Element might not exist on this page
        }
    }
    
    if (interactionIssues.length > 0) {
        console.log(`    ⚠️  Found ${interactionIssues.length} interactive element issues:`);
        interactionIssues.forEach(issue => {
            console.log(`      - ${issue.element}: ${issue.issue}`);
        });
    } else {
        console.log(`    ✅ Interactive elements look good`);
    }
}

async function takeScreenshots(browser) {
    console.log('\n📸 Taking screenshots of all pages...');
    
    const pages = [
        { name: 'home', url: 'http://localhost:8080/' },
        { name: 'about', url: 'http://localhost:8080/about.html' },
        { name: 'product', url: 'http://localhost:8080/product.html' },
        { name: 'contact', url: 'http://localhost:8080/contact.html' }
    ];
    
    for (const pageInfo of pages) {
        const page = await browser.newPage();
        
        try {
            await page.goto(pageInfo.url);
            await page.waitForTimeout(2000);
            
            // Dark mode screenshot
            await page.evaluate(() => {
                document.documentElement.setAttribute('data-theme', 'dark');
            });
            await page.waitForTimeout(1000);
            await page.screenshot({ 
                path: `screenshot-${pageInfo.name}-dark.png`, 
                fullPage: true 
            });
            
            // Light mode screenshot
            await page.evaluate(() => {
                document.documentElement.setAttribute('data-theme', 'light');
            });
            await page.waitForTimeout(1000);
            await page.screenshot({ 
                path: `screenshot-${pageInfo.name}-light.png`, 
                fullPage: true 
            });
            
            console.log(`  ✅ Screenshots saved for ${pageInfo.name}`);
            
        } catch (error) {
            console.error(`  ❌ Error taking screenshots for ${pageInfo.name}:`, error);
        } finally {
            await page.close();
        }
    }
}

// Run the test
testWebsite().catch(console.error); 