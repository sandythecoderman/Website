const { chromium } = require('playwright');

async function debugEyeTracking() {
    const browser = await chromium.launch({ headless: false });
    const page = await browser.newPage();
    
    console.log('🚀 Starting eye tracking debug...');
    
    // Navigate to the website
    await page.goto('http://localhost:8080');
    console.log('✅ Page loaded');
    
    // Wait for the page to fully load
    await page.waitForTimeout(2000);
    
    // Check if PC eyes elements exist
    const pcContainer = await page.$('.pc-container');
    const leftEye = await page.$('.left-eye .pupil');
    const rightEye = await page.$('.right-eye .pupil');
    
    console.log('🔍 Element check:');
    console.log('- PC Container:', !!pcContainer);
    console.log('- Left Eye:', !!leftEye);
    console.log('- Right Eye:', !!rightEye);
    
    if (!pcContainer || !leftEye || !rightEye) {
        console.log('❌ Missing elements!');
        await browser.close();
        return;
    }
    
    // Get initial positions
    const initialLeftTransform = await leftEye.getAttribute('style');
    const initialRightTransform = await rightEye.getAttribute('style');
    console.log('📊 Initial positions:');
    console.log('- Left eye style:', initialLeftTransform);
    console.log('- Right eye style:', initialRightTransform);
    
    // Check if PC eyes animation is active
    const pcEyesAnimation = await page.$('.pc-eyes-animation.active');
    console.log('🎭 PC Eyes Animation Active:', !!pcEyesAnimation);
    
    // Get the bounding box of the PC container
    const containerBox = await pcContainer.boundingBox();
    console.log('📦 Container bounds:', containerBox);
    
    // Test mouse movement
    console.log('🖱️ Testing mouse movement...');
    
    // Move mouse to center of container
    const centerX = containerBox.x + containerBox.width / 2;
    const centerY = containerBox.y + containerBox.height / 2;
    
    await page.mouse.move(centerX, centerY);
    await page.waitForTimeout(500);
    
    // Move mouse to different positions
    const testPositions = [
        { x: centerX - 50, y: centerY - 50, name: 'top-left' },
        { x: centerX + 50, y: centerY - 50, name: 'top-right' },
        { x: centerX - 50, y: centerY + 50, name: 'bottom-left' },
        { x: centerX + 50, y: centerY + 50, name: 'bottom-right' }
    ];
    
    for (const pos of testPositions) {
        console.log(`🔄 Moving mouse to ${pos.name}...`);
        await page.mouse.move(pos.x, pos.y);
        await page.waitForTimeout(1000);
        
        // Check if eyes moved
        const leftTransform = await leftEye.getAttribute('style');
        const rightTransform = await rightEye.getAttribute('style');
        
        console.log(`📍 ${pos.name} positions:`);
        console.log('- Left eye:', leftTransform);
        console.log('- Right eye:', rightTransform);
        
        // Check if transforms changed
        if (leftTransform !== initialLeftTransform) {
            console.log('✅ Left eye moved!');
        } else {
            console.log('❌ Left eye did not move');
        }
        
        if (rightTransform !== initialRightTransform) {
            console.log('✅ Right eye moved!');
        } else {
            console.log('❌ Right eye did not move');
        }
    }
    
    // Check JavaScript console for errors
    const logs = [];
    page.on('console', msg => {
        logs.push(msg.text());
        console.log('📝 Console:', msg.text());
    });
    
    // Check for JavaScript errors
    page.on('pageerror', error => {
        console.log('🚨 JavaScript Error:', error.message);
    });
    
    // Test the JavaScript functions directly
    console.log('🔧 Testing JavaScript functions...');
    
    const jsTest = await page.evaluate(() => {
        const pcContainer = document.querySelector('.pc-container');
        const leftEye = document.querySelector('.left-eye .pupil');
        const rightEye = document.querySelector('.right-eye .pupil');
        
        console.log('JS Test - Elements found:', {
            pcContainer: !!pcContainer,
            leftEye: !!leftEye,
            rightEye: !!rightEye
        });
        
        if (pcContainer && leftEye && rightEye) {
            // Test if event listeners are attached
            const events = getEventListeners ? getEventListeners(pcContainer) : 'getEventListeners not available';
            console.log('Event listeners:', events);
            
            // Test manual eye movement
            leftEye.style.transform = 'translate(calc(-50% + 10px), calc(-50% + 10px))';
            rightEye.style.transform = 'translate(calc(-50% + 10px), calc(-50% + 10px))';
            
            return {
                success: true,
                leftTransform: leftEye.style.transform,
                rightTransform: rightEye.style.transform
            };
        }
        
        return { success: false };
    });
    
    console.log('🧪 JavaScript test result:', jsTest);
    
    // Wait a bit more to see if the test animation runs
    console.log('⏳ Waiting for test animation...');
    await page.waitForTimeout(3000);
    
    // Final position check
    const finalLeftTransform = await leftEye.getAttribute('style');
    const finalRightTransform = await rightEye.getAttribute('style');
    console.log('🏁 Final positions:');
    console.log('- Left eye:', finalLeftTransform);
    console.log('- Right eye:', finalRightTransform);
    
    await browser.close();
    console.log('✅ Debug complete!');
}

debugEyeTracking().catch(console.error); 